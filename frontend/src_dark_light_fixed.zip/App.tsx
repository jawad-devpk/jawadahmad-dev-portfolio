// import RouteScrollToTop from "./components/layout/RouteScrollToTop";
// import AppRoutes from "./routes/AppRoutes";

// function App() {
//   return (
//     <>
//       <RouteScrollToTop />
//       <AppRoutes />
//     </>
//   );
// }

// export default App;
import AppRoutes from "./routes/AppRoutes";

function App() {
  return <AppRoutes />;
}

export default App;
