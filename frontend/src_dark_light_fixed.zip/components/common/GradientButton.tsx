import type { MouseEventHandler, ReactNode } from "react";

type GradientButtonProps = {
  children: ReactNode;
  href?: string;
  className?: string;
  onClick?: MouseEventHandler<HTMLAnchorElement>;
};

export default function GradientButton({
  children,
  href = "#",
  className = "",
  onClick,
}: GradientButtonProps) {
  return (
    <a
      href={href}
      onClick={onClick}
      className={`inline-flex items-center justify-center rounded-md bg-[#9D22F2] px-7 py-3 text-[16px] font-bold text-white shadow-[0_18px_45px_rgba(157,34,242,0.35)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#8B18E8] ${className}`}
    >
      {children}
    </a>
  );
}
