import { MessageCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function FloatingChatButton() {
  return (
    <motion.a
      href="#contact"
      initial={{ opacity: 0, scale: 0.85 }}
      animate={{ opacity: 1, scale: [1, 1.08, 1] }}
      transition={{
        opacity: { duration: 0.4 },
        scale: {
          duration: 2.4,
          repeat: Infinity,
          ease: "easeInOut",
        },
      }}
      className="fixed bottom-7 right-7 z-[60] flex h-[62px] w-[62px] items-center justify-center rounded-full bg-[#9D22F2] text-white shadow-[0_18px_45px_rgba(157,34,242,0.45)] transition-all duration-300 hover:-translate-y-1 hover:bg-[#8B18E8] sm:h-[68px] sm:w-[68px]"
      aria-label="Open AI assistant"
    >
      <MessageCircle size={30} fill="white" strokeWidth={1.8} />
    </motion.a>
  );
}
