import { Moon, Sun } from "lucide-react";
import { useTheme } from "../../context/ThemeContext";

export default function ThemeToggleButton() {
  const { isDark, toggleTheme } = useTheme();

  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label="Toggle dark and light mode"
      title={isDark ? "Switch to light mode" : "Switch to dark mode"}
      className="flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-[#151D26] text-[#AAB3BE] shadow-[0_12px_32px_rgba(0,0,0,0.25)] transition-all duration-300 hover:border-[#9D22F2]/50 hover:bg-[#202A35] hover:text-white"
    >
      {isDark ? <Sun size={19} /> : <Moon size={19} />}
    </button>
  );
}
